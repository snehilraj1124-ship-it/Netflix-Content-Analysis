# Netflix Content Analysis — Extended Portfolio Project

## Objective
Analyze a streaming-content catalog across format, genre, geography, time, ratings and synthetic performance metrics.

## Dataset
- **3,000 synthetic records**
- 12 genres
- 12 countries
- Release years 2010–2025
- Movies and TV Shows
- Ratings, popularity, views, budget, nominations and audience score

## Key Results
- Movies: 68.9%
- TV Shows: 31.1%
- Most represented genre: **Action**
- Most represented country: **United States**
- Most common rating: **TV-MA**
- Highest average-view genre: **Comedy**

## Business Use Cases
Content acquisition, genre portfolio analysis, regional strategy, audience analysis, catalog monitoring and data storytelling.

## Visualizations
Seven charts are included covering content type, release year, genre, country, views vs audience score, genre-level views and country-level audience score.

## Excel
The workbook contains Content Data, By Type, By Genre, By Country, By Year, By Rating and Genre × Type sheets.

## Disclaimer
All data and performance metrics are synthetic and must not be represented as actual Netflix data.
