import pandas as pd
import matplotlib.pyplot as plt

df=pd.read_csv("netflix_content_dataset_extended.csv")
print("Shape:",df.shape)
print("\nContent type:\n",df["Type"].value_counts())
print("\nGenre summary:\n",df.groupby("Genre").agg(
    Titles=("Content_ID","count"),
    Avg_Views_Million=("Views_Million","mean"),
    Avg_Audience_Score=("Audience_Score","mean")
).sort_values("Avg_Views_Million",ascending=False).round(2))
print("\nCountry summary:\n",df.groupby("Country").agg(
    Titles=("Content_ID","count"),
    Avg_Views_Million=("Views_Million","mean"),
    Avg_Audience_Score=("Audience_Score","mean")
).sort_values("Titles",ascending=False).round(2))
