# Netflix Content Analysis — Extended

## Overview
Extended streaming-content analytics project using **3,000 synthetic records**.

## Analysis
- Movies vs TV Shows
- Genre and country distribution
- Release-year trends
- Ratings
- Popularity and views
- Views vs audience score
- Average views by genre
- Audience score by country
- Genre × Type analysis

## Technologies
Python, Pandas, NumPy, Matplotlib, Excel/OpenPyXL, EDA and Business Analytics.

## Files
- `netflix_content_dataset_extended.csv`
- `netflix_content_analysis_extended.py`
- `netflix_content_analysis_extended.xlsx`
- Seven PNG visualizations
- `analysis_report.md`
- `README.md`

## Disclaimer
All records and performance metrics are synthetic and are for educational/portfolio use only. They do not represent Netflix's actual catalog or internal statistics.
